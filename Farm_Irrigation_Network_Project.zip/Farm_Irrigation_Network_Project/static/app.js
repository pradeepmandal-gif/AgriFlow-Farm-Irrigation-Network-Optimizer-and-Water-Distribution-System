(() => {
  const data = window.NETWORK_DATA || {nodes:[],pipes:[],mst_ids:[]};
  const svg = document.getElementById('mapSvg');
  const ns = 'http://www.w3.org/2000/svg';
  let mstMode = false;
  function el(tag, attrs={}, text='') {
    const n = document.createElementNS(ns,tag);
    Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,v));
    if(text) n.textContent=text;
    return n;
  }
  function renderMap() {
    if(!svg) return;
    svg.innerHTML='';
    const bg=el('g');
    for(let x=30;x<700;x+=35) for(let y=20;y<350;y+=35) bg.appendChild(el('circle',{cx:x,cy:y,r:1,fill:'#dce9df'}));
    svg.appendChild(bg);
    const nodes=data.nodes, pipes=data.pipes;
    const coords={};
    nodes.forEach(n=>{
      coords[n.id]={x:30+(Math.max(0,Math.min(100,Number(n.x)||0))/100)*640,y:20+(Math.max(0,Math.min(100,Number(n.y)||0))/100)*300};
    });
    pipes.forEach(p=>{
      const a=coords[p.source_id],b=coords[p.target_id]; if(!a||!b)return;
      const edge=el('line',{x1:a.x,y1:a.y,x2:b.x,y2:b.y,class:'map-edge'+(mstMode&&data.mst_ids.includes(p.id)?' mst':'')});
      edge.dataset.pipe=p.id;
      edge.appendChild(el('title',{},`${p.source_name} → ${p.target_name}: ${p.length} m`));
      svg.appendChild(edge);
    });
    nodes.forEach(n=>{
      const c=coords[n.id],kind=(n.kind||'field').toLowerCase();
      const color=kind==='source'?'#269963':kind==='pump'?'#e6a34b':kind==='valve'?'#54a5ce':kind==='tank'?'#5299a3':'#8f7ae0';
      const g=el('g',{class:'map-node',tabindex:0,role:'button','aria-label':n.name});
      g.appendChild(el('circle',{cx:c.x,cy:c.y,r:10,fill:color}));
      g.appendChild(el('circle',{cx:c.x,cy:c.y,r:3,fill:'#fff'}));
      const label=el('text',{x:c.x,y:c.y-15,'text-anchor':'middle'},n.name);
      g.appendChild(label);
      g.appendChild(el('title',{},`${n.name} · ${n.kind} · elevation ${n.elevation} m`));
      g.addEventListener('click',()=>{alert(`${n.name}\nType: ${n.kind}\nCrop: ${n.crop}\nWater need: ${n.water_need} m³/day\nElevation: ${n.elevation} m`);});
      g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();g.dispatchEvent(new Event('click'));}});
      svg.appendChild(g);
    });
  }
  renderMap();
  document.getElementById('showMstBtn')?.addEventListener('click',()=>{
    mstMode=!mstMode; renderMap();
    document.getElementById('showMstBtn').textContent=mstMode?'Show all pipes':'Highlight MST';
  });
  document.getElementById('resetMapBtn')?.addEventListener('click',()=>{mstMode=false;renderMap();document.getElementById('showMstBtn').textContent='Highlight MST';});
  document.getElementById('refreshBtn')?.addEventListener('click',()=>location.reload());
  document.getElementById('downloadNetworkBtn')?.addEventListener('click',async()=>{
    try {const r=await fetch('/api/network');const obj=await r.json();download('farm-network.json',JSON.stringify(obj,null,2),'application/json');}
    catch(e){alert('Could not export network. Check that the Flask server is running.');}
  });
  function download(name,content,type){
    const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  }
  const runBtn=document.getElementById('runMstBtn'), mstResult=document.getElementById('optimizationResult');
  runBtn?.addEventListener('click',async()=>{
    runBtn.disabled=true;runBtn.textContent='⏳ Calculating…';
    try{
      const r=await fetch('/optimize',{method:'POST'}),d=await r.json();
      mstResult.classList.remove('hidden');
      mstResult.innerHTML=`<h4>Minimum spanning tree result</h4><div class="result-total">${d.total_length} m</div><p>${d.edges_selected} links selected · ${d.node_count} nodes · ${d.connected?'Connected graph':'⚠ Disconnected graph ('+d.components+' components)'}</p><ul>${d.edges.map(e=>`<li><b>${esc(e.from)} → ${esc(e.to)}</b> — ${e.length} m · terrain cost ${e.weighted_cost}</li>`).join('')}</ul><small>${esc(d.note)}</small>`;
      mstMode=true;renderMap();document.getElementById('showMstBtn').textContent='Show all pipes';
    }catch(e){mstResult.classList.remove('hidden');mstResult.textContent='Optimization failed. Make sure the server is running.';}
    finally{runBtn.disabled=false;runBtn.innerHTML='▶ &nbsp; Run MST optimization';}
  });
  document.getElementById('routeForm')?.addEventListener('submit',async e=>{
    e.preventDefault();const box=document.getElementById('routeResult');box.classList.remove('hidden');box.textContent='Calculating shortest routes…';
    try{
      const r=await fetch('/route',{method:'POST',body:new FormData(e.target)}),d=await r.json();
      if(!d.success)throw new Error(d.error||'Unable to calculate routes');
      box.innerHTML=`<h4>Shortest routes from ${esc(d.start)}</h4><ul>${d.paths.map(p=>`<li><b>${esc(p.destination)}</b>: ${p.reachable?esc(p.route.join(' → '))+' <small>(weighted cost '+p.cost+')</small>':'<span style="color:#b54e40">Unreachable — graph is disconnected</span>'}</li>`).join('')}</ul>`;
    }catch(err){box.textContent=err.message;}
  });
  document.getElementById('generateScheduleBtn')?.addEventListener('click',async()=>{
    const btn=document.getElementById('generateScheduleBtn'),notice=document.getElementById('scheduleNotice');
    btn.disabled=true;btn.textContent='Generating…';
    try{
      const r=await fetch('/schedule/generate',{method:'POST'}),d=await r.json();
      notice.classList.remove('hidden');notice.textContent=`Created ${d.count} irrigation tasks for ${d.date}. ${d.note}`;
      const body=document.getElementById('scheduleTable');
      if(!d.schedule.length){body.innerHTML='<tr class="empty-row"><td colspan="7">No field nodes available. Add a field first.</td></tr>';return;}
      body.innerHTML=d.schedule.map(s=>`<tr><td><strong>${esc(s.name)}</strong><small>${esc(s.crop)}</small></td><td>${Number(s.water_need).toFixed(1)} m³/day</td><td><span class="time-chip">◷ ${s.start_time}</span></td><td>${s.duration} hr</td><td>${Number(s.volume).toLocaleString()} L</td><td><span class="status-pill planned">Planned</span></td><td><span class="muted">Saved</span></td></tr>`).join('');
    }catch(e){notice.classList.remove('hidden');notice.textContent='Could not generate schedule. Check the Flask server and try again.';}
    finally{btn.disabled=false;btn.textContent='✦ Generate schedule';}
  });
  document.getElementById('exportScheduleBtn')?.addEventListener('click',()=>{
    const rows=[...document.querySelectorAll('#scheduleTable tr')].filter(r=>!r.classList.contains('empty-row'));
    const csv=[['Field/Crop','Water demand','Start time','Duration','Planned volume','Status']];
    rows.forEach(r=>csv.push([...r.querySelectorAll('td')].slice(0,6).map(td=>td.innerText.replace(/\s+/g,' ').trim())));
    if(csv.length===1){alert('Generate a schedule first, then export it.');return;}
    download('irrigation-schedule.csv',csv.map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n'),'text/csv;charset=utf-8');
  });
  function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
})();
