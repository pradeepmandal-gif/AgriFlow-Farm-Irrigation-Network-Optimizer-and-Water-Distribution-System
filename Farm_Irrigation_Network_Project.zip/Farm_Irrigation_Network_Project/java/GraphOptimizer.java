import java.util.*;

/**
 * Standalone Java reference implementation of Kruskal's Minimum Spanning Tree.
 * Compile: javac GraphOptimizer.java
 * Run: java GraphOptimizer
 */
public class GraphOptimizer {
    static class Edge {
        int u, v;
        double length;
        Edge(int u, int v, double length) { this.u=u; this.v=v; this.length=length; }
    }
    static class DSU {
        int[] parent, rank;
        DSU(int n) {
            parent = new int[n]; rank = new int[n];
            for (int i=0;i<n;i++) parent[i]=i;
        }
        int find(int x) {
            if (parent[x] != x) parent[x] = find(parent[x]);
            return parent[x];
        }
        boolean union(int a,int b) {
            int ra=find(a), rb=find(b);
            if (ra==rb) return false;
            if (rank[ra]<rank[rb]) { int t=ra;ra=rb;rb=t; }
            parent[rb]=ra;
            if (rank[ra]==rank[rb]) rank[ra]++;
            return true;
        }
    }
    public static List<Edge> kruskal(int nodeCount, List<Edge> edges) {
        List<Edge> sorted = new ArrayList<>(edges);
        sorted.sort(Comparator.comparingDouble(e -> e.length));
        DSU dsu = new DSU(nodeCount);
        List<Edge> mst = new ArrayList<>();
        for (Edge e : sorted) if (dsu.union(e.u,e.v)) mst.add(e);
        return mst;
    }
    public static void main(String[] args) {
        List<Edge> edges = Arrays.asList(
            new Edge(0,1,120), new Edge(0,2,55), new Edge(2,3,95),
            new Edge(2,4,105), new Edge(1,3,88), new Edge(1,2,90),
            new Edge(3,4,65), new Edge(3,5,115), new Edge(0,4,165)
        );
        List<Edge> mst = kruskal(6, edges);
        double total = mst.stream().mapToDouble(e -> e.length).sum();
        System.out.println("Kruskal Minimum Spanning Tree");
        for (Edge e : mst) System.out.printf("Node %d -- Node %d : %.1f m%n", e.u, e.v, e.length);
        System.out.printf("Selected edges: %d%nTotal physical length: %.1f m%n", mst.size(), total);
        System.out.println("Expected for a connected graph: V - 1 edges.");
    }
}
